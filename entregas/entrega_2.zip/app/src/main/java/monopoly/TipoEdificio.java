package monopoly;

public class TipoEdificio {

}

